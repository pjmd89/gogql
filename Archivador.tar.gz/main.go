package main

import (
	"embed"
	"fmt"

	"github.com/pjmd89/gogql/lib/gql"
	"github.com/pjmd89/gogql/lib/http"
	"github.com/pjmd89/gogql/lib/rest"
	"github.com/pjmd89/gogql/resolvers/objecttype"
	"github.com/pjmd89/gogql/resolvers/objecttype/purchase"
	"github.com/pjmd89/gogql/resolvers/objecttype/testunion"
	"github.com/pjmd89/gogql/resolvers/objecttype/theme"
	"github.com/pjmd89/gogql/resolvers/objecttype/user"
	"github.com/pjmd89/goutils/systemutils"
	"github.com/pjmd89/goutils/systemutils/debugmode"
)

//go:embed "schema"
var embedFS embed.FS

var schema = gql.Init(embedFS, "schema")
var systemLog = systemutils.NewLog("etc/error.log")
var accessLog = systemutils.NewLog("etc/acess.log")
var logs = systemutils.Logs{System: systemLog, Access: accessLog}
var restObject = rest.Init()

func main() {
  var myHttp = http.Init(logs, "./etc/http/http.json").SetGql(schema).SetRest(restObject)
  systemLog.Info().Println("debugmode: ", debugmode.Enabled)
  oRest := objecttype.NewRest()
  restObject.ObjectType("/rest/[^/]+/pepito/[^\n]+", "rest", oRest)
  schema.ObjectType("Purchase", purchase.NewPurchase())
  schema.ObjectType("TestUnion", testunion.NewTestUnion())
  schema.ObjectType("Theme", theme.NewTheme())
  schema.ObjectType("User", user.NewUser())
  myHttp.Start()
  fmt.Println("hola mundo")
}
