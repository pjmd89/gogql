/*
 * Generado por gqlgenerate.
 *
 * Este archivo puede contener errores, de ser asi, coloca el issue en el repositorio de github
 * https://github.com/pjmd89/gogql
 *
 * Estos arvhivos corren riesgo de sobreescritura, por ese motivo gqlgnerate crea una carpeta llamada generate, asi que,
 * copia todas las carpetas que estan dentro de la carpeta generate y pegalas en la carpeta raiz de tu proyecto.
 *
 * gqlgenerate no creara archivos en la carpeta raiz de tu modulo porque puedes sufrir perdida de informacion.
 */
package theme

import (
	"fmt"

	"github.com/pjmd89/gogql/lib/gql/definitionError"
	"github.com/pjmd89/gogql/lib/resolvers"
	"go.mongodb.org/mongo-driver/bson/primitive"
)
type Theme struct {
	Id                  primitive.ObjectID `gql:"name=_id,id=true,objectID=true"`
	Template			string              `gql:"name=template"`
}

 func NewTheme() (o resolvers.ObjectTypeInterface) {
	 return &Theme{}
 }
 
  func (o *Theme) Resolver(info resolvers.ResolverInfo) (r resolvers.DataReturn, err definitionError.GQLError) {
	  switch info.Operation {
	  case "query":
		  switch info.Resolver {
		  case "NewX":
			  r, err = o.testUnionQuery(info)
		  }
	  }
	  return
  }
  func (o *Theme) Subscribe(info resolvers.ResolverInfo) (r bool) {
	  return
  }
  
  func (o *Theme) testUnionQuery(info resolvers.ResolverInfo) (r resolvers.DataReturn, err definitionError.GQLError) {
	 fmt.Println("hello World")
	 x := Theme{
		Template: "hola Mundo",
	 }
	 if _, ok := info.Parent.(map[string]any)["theme"]; ok && info.Parent.(map[string]any)["theme"] == "b"{
		r = x
	}
	return
  }
  