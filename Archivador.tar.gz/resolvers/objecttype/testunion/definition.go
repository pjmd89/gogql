package testunion

import (
	"fmt"

	"github.com/pjmd89/gogql/lib/gql/definitionError"
	"github.com/pjmd89/gogql/lib/resolvers"
)

type Test_union struct{
	Id string //`gql:"name=_id"`
	
}

func NewTestUnion() (o resolvers.ObjectTypeInterface) {
	return &Test_union{}
}

 func (o *Test_union) Resolver(info resolvers.ResolverInfo) (r resolvers.DataReturn, err definitionError.GQLError) {
	 switch info.Operation {
	 case "query":
		 switch info.Resolver {
		 case "NewX":
			 r, err = o.testUnionQuery(info)
		 }
	 }
	 return
 }
 func (o *Test_union) Subscribe(info resolvers.ResolverInfo) (r bool) {
	 return
 }
 
 func (o *Test_union) testUnionQuery(info resolvers.ResolverInfo) (r resolvers.DataReturn, err definitionError.GQLError) {

	x := []map[string]any{
		{
			"user": "a",
		},
		{
			"theme": "b",
		},
		{
			"theme": "x",
		},
		{
			"user": "b",
		},
	}
	fmt.Println("hello World")
	r = x
	return
 }