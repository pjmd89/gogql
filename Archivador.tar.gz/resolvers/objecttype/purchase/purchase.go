/*
 * Generado por gqlgenerate.
 *
 * Este archivo puede contener errores, de ser asi, coloca el issue en el repositorio de github
 * https://github.com/pjmd89/gogql
 *
 * Estos arvhivos corren riesgo de sobreescritura, por ese motivo gqlgnerate crea una carpeta llamada generate, asi que,
 * copia todas las carpetas que estan dentro de la carpeta generate y pegalas en la carpeta raiz de tu proyecto.
 *
 * gqlgenerate no creara archivos en la carpeta raiz de tu modulo porque puedes sufrir perdida de informacion.
 */
package purchase

import (
	"github.com/pjmd89/gogql/lib/gql/definitionError"
	"github.com/pjmd89/gogql/lib/resolvers"
	"go.mongodb.org/mongo-driver/bson/primitive"
)
type Purchase struct {
	 Id                  primitive.ObjectID `gql:"name=_id,id=true,objectID=true"`
	 PurchaseOrderNumber int64              `gql:"name=purchaseOrderNumber"`
	 ExchangeRate        float64            `gql:"name=exchangeDate"`
}
 
 // ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 func NewPurchase() (o resolvers.ObjectTypeInterface) {
	 return &Purchase{}
 }
 
 func (o *Purchase) Resolver(info resolvers.ResolverInfo) (r resolvers.DataReturn, err definitionError.GQLError) {
	 switch info.Operation {
	 case "query":
		 switch info.Resolver {
		 case "readPurchase":
			 r, err = o.purchaseQuery(info)
		 }
	 }
	 return
 }
 func (o *Purchase) Subscribe(info resolvers.ResolverInfo) (r bool) {
	 return
 }
 
 func (o *Purchase) purchaseQuery(info resolvers.ResolverInfo) (r resolvers.DataReturn, err definitionError.GQLError) {
	 id, _ := primitive.ObjectIDFromHex("671a72bb414e8369562643e1")
 
	 r = Purchase{
		 Id:                  id,
		 PurchaseOrderNumber: 1,
		 ExchangeRate:        90,
	 }
 
	 return
 }
 