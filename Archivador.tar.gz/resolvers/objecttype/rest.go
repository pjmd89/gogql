package objecttype

import (
	"fmt"

	"github.com/pjmd89/gogql/lib/gql/definitionError"
	"github.com/pjmd89/gogql/lib/resolvers"
)

type Rest struct {
}

func NewRest() (o resolvers.ObjectTypeInterface) {
	o = &Rest{}
	return
}
func (o *Rest) Resolver(info resolvers.ResolverInfo) (r resolvers.DataReturn, err definitionError.GQLError) {
	fmt.Println(info)
	r = "hola mundo"
	info.RestInfo.SetHeader("hola", "mundo")
	return
}
func (o *Rest) Subscribe(info resolvers.ResolverInfo) (r bool) {
	return
}
